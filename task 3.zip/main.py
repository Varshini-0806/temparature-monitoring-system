import machine
import time
import dht

class I2cLcd:
    def __init__(self, i2c, address, num_lines=2, num_columns=16):
        self.i2c = i2c
        self.addr = address
        self.num_lines = num_lines
        self.num_columns = num_columns
        self.backlight = 0x08  # Backlight on
        self.EN = 0b00000100   # Enable bit
        self.RS = 0b00000001   # Register select bit
        self._init_lcd()

    def _write_byte(self, data):
        self.i2c.writeto(self.addr, bytearray([data | self.backlight]))

    def _toggle_enable(self, data):
        self._write_byte(data | self.EN)
        time.sleep_us(500)
        self._write_byte(data & ~self.EN)
        time.sleep_us(100)

    def _send(self, data, mode):
        high = data & 0xF0
        low = (data << 4) & 0xF0
        self._write_4bits(high | mode)
        self._write_4bits(low | mode)

    def _write_4bits(self, data):
        self._write_byte(data)
        self._toggle_enable(data)

    def command(self, cmd):
        self._send(cmd, 0)

    def write(self, char):
        self._send(char, self.RS)

    def putstr(self, string):
        for char in string:
            self.write(ord(char))

    def clear(self):
        self.command(0x01)
        time.sleep_ms(2)

    def move_to(self, col, row):
        row_offsets = [0x00, 0x40]
        self.command(0x80 | (col + row_offsets[row]))

    def _init_lcd(self):
        time.sleep_ms(50)
        self._write_4bits(0x30)
        time.sleep_ms(5)
        self._write_4bits(0x30)
        time.sleep_us(200)
        self._write_4bits(0x30)
        self._write_4bits(0x20)  # 4-bit mode
        self.command(0x28)       # Function set
        self.command(0x08)       # Display off
        self.command(0x01)       # Clear display
        time.sleep_ms(2)
        self.command(0x06)       # Entry mode set
        self.command(0x0C)       # Display on

# --- Setup DHT22 Sensor ---
DHT_PIN = 18
sensor = dht.DHT22(machine.Pin(DHT_PIN))

# --- Setup I2C and LCD ---
i2c = machine.I2C(0, scl=machine.Pin(22), sda=machine.Pin(21), freq=400000)
lcd_address = 0x27  # Use I2C scan to confirm
lcd = I2cLcd(i2c, lcd_address, 2, 16)

print("Starting DHT22 Sensor with LCD...")

# --- Main Loop ---
while True:
    try:
        sensor.measure()
        temp = sensor.temperature()
        humidity = sensor.humidity()

        # Display on LCD
        lcd.clear()
        lcd.move_to(0, 0)
        lcd.putstr("Temp: {:.1f} C".format(temp))
        lcd.move_to(0, 1)
        lcd.putstr("Humidity: {:.1f}%".format(humidity))

        # Debug Print
        print(f"Temp: {temp:.1f} C, Humidity: {humidity:.1f}%")

    except Exception as e:
        print("Error reading DHT22:", e)
        lcd.clear()
        lcd.putstr("Sensor Error")

    time.sleep(2)
